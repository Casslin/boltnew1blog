import archiver from 'archiver';
import fs from 'fs';
import path from 'path';

// Create output directory if it doesn't exist
if (!fs.existsSync('dist')) {
  fs.mkdirSync('dist');
}

// Create a file to stream archive data to
const output = fs.createWriteStream('dist/github-upload.zip');
const archive = archiver('zip', {
  zlib: { level: 9 } // Sets the compression level
});

// Listen for all archive data to be written
output.on('close', () => {
  console.log(`Archive created: ${archive.pointer()} total bytes`);
  console.log('Archive has been finalized and the output file descriptor has been closed.');
  console.log('Your zip file is ready at dist/github-upload.zip');
});

// Good practice to catch warnings (ie stat failures and other non-blocking errors)
archive.on('warning', (err) => {
  if (err.code === 'ENOENT') {
    console.warn(err);
  } else {
    throw err;
  }
});

// Good practice to catch this error explicitly
archive.on('error', (err) => {
  throw err;
});

// Pipe archive data to the file
archive.pipe(output);

// Add files and directories
const filesToExclude = [
  'node_modules',
  'dist',
  '.git',
  '.DS_Store',
  'github-upload.zip'
];

function addDirectory(dirPath) {
  const files = fs.readdirSync(dirPath);
  
  files.forEach(file => {
    const fullPath = path.join(dirPath, file);
    const relativePath = path.relative('.', fullPath);
    
    if (filesToExclude.some(exclude => relativePath.includes(exclude))) {
      return;
    }
    
    const stat = fs.statSync(fullPath);
    
    if (stat.isDirectory()) {
      addDirectory(fullPath);
    } else {
      archive.file(fullPath, { name: relativePath });
    }
  });
}

// Add all files from the current directory
addDirectory('.');

// Finalize the archive
archive.finalize();