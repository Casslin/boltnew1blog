import { Meeting } from '../types/meeting';

export function filterMeetings(
  meetings: Meeting[],
  searchTerm: string,
  statusFilter: 'all' | 'upcoming' | 'completed'
): Meeting[] {
  return meetings.filter(meeting => {
    const matchesSearch = 
      searchTerm === '' ||
      meeting.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      meeting.actionItems.some(item => 
        item.text.toLowerCase().includes(searchTerm.toLowerCase()) ||
        item.assignee.toLowerCase().includes(searchTerm.toLowerCase())
      );
    
    const matchesStatus = statusFilter === 'all' || meeting.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });
}