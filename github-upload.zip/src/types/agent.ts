export interface Message {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
  type: 'text' | 'summary' | 'strategy';
}

export interface WebsiteSummary {
  url: string;
  title: string;
  summary: string;
  timestamp: string;
}

export interface TradingStrategy {
  id: string;
  name: string;
  description: string;
  signals: string[];
  confidence: number;
  timestamp: string;
}

export interface Framework {
  id: string;
  name: string;
  description: string;
  rules: string[];
  active: boolean;
}