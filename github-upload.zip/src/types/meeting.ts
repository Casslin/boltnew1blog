export interface Meeting {
  id: string;
  title: string;
  date: string;
  startTime: string;
  endTime: string;
  attendees: string[];
  status: 'upcoming' | 'completed';
  actionItems: ActionItem[];
  relatedDocs: RelatedDocument[];
}

export interface ActionItem {
  id: string;
  text: string;
  assignee: string;
  dueDate: string;
  status: 'pending' | 'completed';
}

export interface RelatedDocument {
  id: string;
  title: string;
  type: 'email' | 'doc' | 'presentation';
  lastModified: string;
  url: string;
}