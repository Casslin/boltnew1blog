export interface Post {
  id: string;
  title: string;
  content: string;
  excerpt: string;
  slug: string;
  author: Author;
  publishedAt: string;
  status: 'draft' | 'published';
  socialPlatforms: SocialPlatformStatus[];
  tags: string[];
  coverImage?: string;
}

export interface Author {
  id: string;
  name: string;
  avatar: string;
  bio: string;
  socialLinks: {
    twitter?: string;
    linkedin?: string;
    github?: string;
  };
}

export interface SocialPlatformStatus {
  platform: 'twitter' | 'linkedin' | 'medium' | 'farcaster' | 'bluesky' | 'ipfs' | 'ens' | 'sol';
  status: 'pending' | 'published' | 'failed';
  publishedUrl?: string;
  scheduledFor?: string;
  cid?: string;
  domain?: string;
}