import { Message, WebsiteSummary, TradingStrategy, Framework } from '../types/agent';

export const mockMessages: Message[] = [
  {
    id: '1',
    role: 'system',
    content: 'AI Trading Assistant initialized. Monitoring 5 financial websites for market insights.',
    timestamp: new Date().toISOString(),
    type: 'text'
  },
  {
    id: '2',
    role: 'assistant',
    content: 'Latest website summaries analyzed. Key trends detected in tech sector.',
    timestamp: new Date().toISOString(),
    type: 'summary'
  }
];

export const mockWebsites = [
  'https://www.bloomberg.com',
  'https://www.reuters.com',
  'https://www.ft.com',
  'https://www.wsj.com',
  'https://www.cnbc.com'
];

export const mockSummaries: WebsiteSummary[] = [
  {
    url: 'https://www.bloomberg.com',
    title: 'Bloomberg Markets',
    summary: 'Fed signals potential rate cuts in coming months. Tech stocks rally on AI developments.',
    timestamp: new Date().toISOString()
  },
  {
    url: 'https://www.reuters.com',
    title: 'Reuters Business',
    summary: 'Global supply chains showing signs of normalization. Semiconductor shortage easing.',
    timestamp: new Date().toISOString()
  }
];

export const mockFrameworks: Framework[] = [
  {
    id: 'f1',
    name: 'Trend Following',
    description: 'Focus on momentum and market trends',
    rules: [
      'Enter trades in direction of major trend',
      'Use moving averages for trend confirmation',
      'Monitor volume for validation'
    ],
    active: true
  },
  {
    id: 'f2',
    name: 'Mean Reversion',
    description: 'Capitalize on price returning to average',
    rules: [
      'Identify overbought/oversold conditions',
      'Monitor volatility levels',
      'Use statistical indicators'
    ],
    active: false
  }
];

export const mockStrategies: TradingStrategy[] = [
  {
    id: 's1',
    name: 'Tech Sector Momentum',
    description: 'Long position in tech sector based on positive AI developments',
    signals: [
      'Increased institutional buying',
      'Positive news sentiment',
      'Above-average volume'
    ],
    confidence: 0.85,
    timestamp: new Date().toISOString()
  }
];