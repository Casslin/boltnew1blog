import { Post } from '../types/blog';

export const mockPosts: Post[] = [
  {
    id: '1',
    title: 'Getting Started with React and TypeScript',
    content: '# Getting Started\n\nReact and TypeScript...',
    excerpt: 'Learn how to set up a new React project with TypeScript and best practices for type safety.',
    slug: 'getting-started-react-typescript',
    author: {
      id: 'author1',
      name: 'Sarah Johnson',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150',
      bio: 'Senior Frontend Developer',
      socialLinks: {
        twitter: 'https://twitter.com/sarahj',
        github: 'https://github.com/sarahj'
      }
    },
    publishedAt: '2024-03-20T10:00:00Z',
    status: 'published',
    socialPlatforms: [
      {
        platform: 'twitter',
        status: 'pending',
        scheduledFor: '2024-03-21T15:00:00Z'
      },
      {
        platform: 'farcaster',
        status: 'pending',
        scheduledFor: '2024-03-21T16:00:00Z'
      },
      {
        platform: 'bluesky',
        status: 'published',
        publishedUrl: 'https://bsky.app/profile/sarahj.bsky.social/post/123'
      }
    ],
    tags: ['React', 'TypeScript', 'Web Development'],
    coverImage: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=1200'
  },
  {
    id: '2',
    title: 'Advanced State Management Patterns',
    content: '# State Management\n\nModern web applications...',
    excerpt: 'Explore advanced patterns for managing state in React applications.',
    slug: 'advanced-state-management-patterns',
    author: {
      id: 'author1',
      name: 'Sarah Johnson',
      avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150',
      bio: 'Senior Frontend Developer',
      socialLinks: {
        twitter: 'https://twitter.com/sarahj',
        github: 'https://github.com/sarahj'
      }
    },
    publishedAt: '2024-03-19T14:30:00Z',
    status: 'draft',
    socialPlatforms: [],
    tags: ['React', 'State Management', 'JavaScript'],
    coverImage: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=1200'
  }
];