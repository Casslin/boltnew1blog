import { SocialPlatformStatus } from '../types/blog';
import { publishToIPFS, publishToDomain } from './ipfsService';

export interface PostScheduleRequest {
  content: string;
  platforms: {
    platform: SocialPlatformStatus['platform'];
    scheduledFor?: string;
  }[];
}

export async function schedulePost(request: PostScheduleRequest): Promise<SocialPlatformStatus[]> {
  // Simulate API call to schedule posts
  return request.platforms.map(({ platform, scheduledFor }) => ({
    platform,
    status: 'pending',
    scheduledFor: scheduledFor || new Date().toISOString()
  }));
}

export function generatePlatformSpecificContent(
  content: string,
  platform: SocialPlatformStatus['platform']
): string {
  const limits: Record<SocialPlatformStatus['platform'], number> = {
    twitter: 280,
    linkedin: 3000,
    medium: Infinity,
    farcaster: 320,
    bluesky: 300,
    ipfs: Infinity,
    ens: Infinity,
    sol: Infinity
  };

  let optimizedContent = content;
  const limit = limits[platform];

  if (content.length > limit && limit !== Infinity) {
    optimizedContent = content.slice(0, limit - 4) + '...';
  }

  // Add platform-specific formatting
  switch (platform) {
    case 'twitter':
    case 'farcaster':
      // Convert markdown links to plain URLs
      optimizedContent = optimizedContent.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '$2');
      break;
    case 'linkedin':
      // Enhance with professional formatting
      optimizedContent = optimizedContent.replace(/^# (.*)/gm, '📌 $1');
      break;
    case 'medium':
      // Preserve markdown formatting
      break;
    case 'bluesky':
      // Similar to Twitter formatting
      optimizedContent = optimizedContent.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '$2');
      break;
    case 'ipfs':
    case 'ens':
    case 'sol':
      // Preserve all formatting for decentralized platforms
      break;
  }

  return optimizedContent;
}

export async function publishToDecentralized(
  content: string,
  platform: 'ipfs' | 'ens' | 'sol',
  domain?: string
): Promise<SocialPlatformStatus> {
  try {
    // First publish to IPFS
    const ipfsResult = await publishToIPFS(content, {
      platform,
      domain
    });

    // If ENS or Solana domain is specified, publish to domain
    if ((platform === 'ens' || platform === 'sol') && domain) {
      const domainResult = await publishToDomain(
        ipfsResult.url,
        domain,
        platform === 'ens' ? 'ens' : 'sol'
      );

      return {
        platform,
        status: 'published',
        publishedUrl: domainResult.url,
        cid: ipfsResult.cid,
        domain: domainResult.domain
      };
    }

    // IPFS-only publication
    return {
      platform: 'ipfs',
      status: 'published',
      publishedUrl: ipfsResult.url,
      cid: ipfsResult.cid
    };
  } catch (error) {
    console.error('Failed to publish to decentralized platform:', error);
    return {
      platform,
      status: 'failed'
    };
  }
}