import { Web3Storage } from 'web3.storage';

const WEB3_STORAGE_TOKEN = 'your-token-here'; // In production, use environment variables

export interface IPFSPublishResult {
  cid: string;
  url: string;
  timestamp: string;
}

export interface DomainPublishResult {
  domain: string;
  type: 'ens' | 'sol';
  url: string;
  timestamp: string;
}

export async function publishToIPFS(content: string, metadata: Record<string, any>): Promise<IPFSPublishResult> {
  try {
    const client = new Web3Storage({ token: WEB3_STORAGE_TOKEN });
    
    // Create content with metadata
    const contentWithMeta = JSON.stringify({
      content,
      metadata: {
        ...metadata,
        timestamp: new Date().toISOString(),
        type: 'blog-post'
      }
    });

    // Convert to Blob and upload
    const blob = new Blob([contentWithMeta], { type: 'application/json' });
    const file = new File([blob], 'post.json');
    const cid = await client.put([file]);

    return {
      cid,
      url: `https://${cid}.ipfs.dweb.link/post.json`,
      timestamp: new Date().toISOString()
    };
  } catch (error) {
    console.error('Failed to publish to IPFS:', error);
    throw error;
  }
}

export async function publishToDomain(
  ipfsUrl: string,
  domain: string,
  type: 'ens' | 'sol'
): Promise<DomainPublishResult> {
  // Simulate domain publishing (in production, implement actual ENS/Solana domain updates)
  return {
    domain,
    type,
    url: type === 'ens' ? `https://${domain}.eth.limo` : `https://${domain}.sol`,
    timestamp: new Date().toISOString()
  };
}