import { uploadToIPFS } from './client';
import { publishToDomain } from './domains';
import { SocialPlatformStatus } from '../../types/blog';

export interface IPFSPublishResult {
  cid: string;
  url: string;
  timestamp: string;
}

export async function publishToIPFS(content: string, metadata: Record<string, any>): Promise<IPFSPublishResult> {
  try {
    const cid = await uploadToIPFS(content, metadata);
    
    return {
      cid,
      url: `https://${cid}.ipfs.dweb.link/post.json`,
      timestamp: new Date().toISOString()
    };
  } catch (error) {
    console.error('Failed to publish to IPFS:', error);
    throw error;
  }
}

export async function publishToDecentralized(
  content: string,
  platform: 'ipfs' | 'ens' | 'sol',
  domain?: string
): Promise<SocialPlatformStatus> {
  try {
    // First publish to IPFS
    const ipfsResult = await publishToIPFS(content, {
      platform,
      domain
    });

    // If ENS or Solana domain is specified, publish to domain
    if ((platform === 'ens' || platform === 'sol') && domain) {
      const domainResult = await publishToDomain(
        ipfsResult.url,
        domain,
        platform === 'ens' ? 'ens' : 'sol'
      );

      return {
        platform,
        status: 'published',
        publishedUrl: domainResult.url,
        cid: ipfsResult.cid,
        domain: domainResult.domain
      };
    }

    // IPFS-only publication
    return {
      platform: 'ipfs',
      status: 'published',
      publishedUrl: ipfsResult.url,
      cid: ipfsResult.cid
    };
  } catch (error) {
    console.error('Failed to publish to decentralized platform:', error);
    return {
      platform,
      status: 'failed'
    };
  }
}