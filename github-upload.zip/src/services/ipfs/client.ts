import { Web3Storage } from 'web3.storage';

const WEB3_STORAGE_TOKEN = 'your-token-here'; // In production, use environment variables

export function getIPFSClient(): Web3Storage {
  return new Web3Storage({ token: WEB3_STORAGE_TOKEN });
}

export async function uploadToIPFS(content: string, metadata: Record<string, any>): Promise<string> {
  const client = getIPFSClient();
  
  const contentWithMeta = JSON.stringify({
    content,
    metadata: {
      ...metadata,
      timestamp: new Date().toISOString(),
      type: 'blog-post'
    }
  });

  const blob = new Blob([contentWithMeta], { type: 'application/json' });
  const file = new File([blob], 'post.json');
  return await client.put([file]);
}