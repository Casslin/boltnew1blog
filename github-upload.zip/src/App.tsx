import React from 'react';
import { Header } from './components/Header';
import { PostList } from './components/PostList';
import { PostEditor } from './components/PostEditor';
import { AIChatAssistant } from './components/AIChatAssistant';
import { mockPosts } from './data/mockPosts';
import { Post } from './types/blog';

function App() {
  const [showEditor, setShowEditor] = React.useState(false);
  const [editingPost, setEditingPost] = React.useState<Post | undefined>();

  const handleEditPost = (post: Post) => {
    setEditingPost(post);
    setShowEditor(true);
  };

  const handleNewPost = () => {
    setEditingPost(undefined);
    setShowEditor(true);
  };

  const handleSavePost = (post: Partial<Post>) => {
    console.log('Saving post:', post);
    setShowEditor(false);
  };

  const handleAISuggestion = (suggestion: { title?: string; content?: string; tags?: string[] }) => {
    if (showEditor) {
      // Update editor with AI suggestions
      console.log('Applying AI suggestion:', suggestion);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <Header onNewPost={handleNewPost} />
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {showEditor ? (
          <PostEditor
            post={editingPost}
            onSave={handleSavePost}
            onCancel={() => setShowEditor(false)}
          />
        ) : (
          <>
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-gray-900">Your Posts</h2>
              <p className="text-gray-600">Manage and publish your content across platforms</p>
            </div>
            <PostList posts={mockPosts} onEditPost={handleEditPost} />
          </>
        )}
      </main>
      <AIChatAssistant onSuggest={handleAISuggestion} />
    </div>
  );
}

export default App;