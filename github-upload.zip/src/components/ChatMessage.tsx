import React from 'react';
import { MessageCircle, TrendingUp, FileText } from 'lucide-react';
import { Message } from '../types/agent';

interface ChatMessageProps {
  message: Message;
}

export function ChatMessage({ message }: ChatMessageProps) {
  const getIcon = () => {
    switch (message.type) {
      case 'summary':
        return <FileText className="w-5 h-5" />;
      case 'strategy':
        return <TrendingUp className="w-5 h-5" />;
      default:
        return <MessageCircle className="w-5 h-5" />;
    }
  };

  return (
    <div className={`flex gap-3 ${
      message.role === 'user' ? 'flex-row-reverse' : 'flex-row'
    }`}>
      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
        message.role === 'user' 
          ? 'bg-blue-100 text-blue-600'
          : message.role === 'system'
          ? 'bg-gray-100 text-gray-600'
          : 'bg-green-100 text-green-600'
      }`}>
        {getIcon()}
      </div>
      
      <div className={`max-w-[80%] rounded-lg p-4 ${
        message.role === 'user'
          ? 'bg-blue-500 text-white'
          : message.role === 'system'
          ? 'bg-gray-100 text-gray-700'
          : 'bg-white shadow-md'
      }`}>
        <p className="text-sm">{message.content}</p>
        <span className="text-xs opacity-70 mt-2 block">
          {new Date(message.timestamp).toLocaleTimeString()}
        </span>
      </div>
    </div>
  );
}