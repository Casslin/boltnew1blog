import React, { useState } from 'react';
import { X, Twitter, Linkedin, BookOpen, Hash, Cloud } from 'lucide-react';

interface Platform {
  id: 'twitter' | 'linkedin' | 'medium' | 'farcaster' | 'bluesky';
  name: string;
  icon: React.ReactNode;
  enabled: boolean;
  scheduledTime?: string;
  characterLimit?: number;
}

interface SocialSchedulerProps {
  onClose: () => void;
  onSchedule: (platforms: Platform[]) => void;
}

export function SocialScheduler({ onClose, onSchedule }: SocialSchedulerProps) {
  const [platforms, setPlatforms] = useState<Platform[]>([
    { id: 'twitter', name: 'Twitter', icon: <Twitter className="w-5 h-5" />, enabled: false, characterLimit: 280 },
    { id: 'linkedin', name: 'LinkedIn', icon: <Linkedin className="w-5 h-5" />, enabled: false, characterLimit: 3000 },
    { id: 'medium', name: 'Medium', icon: <BookOpen className="w-5 h-5" />, enabled: false, characterLimit: undefined },
    { id: 'farcaster', name: 'Farcaster', icon: <Hash className="w-5 h-5" />, enabled: false, characterLimit: 320 },
    { id: 'bluesky', name: 'Bluesky', icon: <Cloud className="w-5 h-5" />, enabled: false, characterLimit: 300 }
  ]);

  const handleTogglePlatform = (platformId: Platform['id']) => {
    setPlatforms(platforms.map(p => 
      p.id === platformId ? { ...p, enabled: !p.enabled } : p
    ));
  };

  const handleTimeChange = (platformId: Platform['id'], time: string) => {
    setPlatforms(platforms.map(p =>
      p.id === platformId ? { ...p, scheduledTime: time } : p
    ));
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
      <div className="bg-white rounded-lg p-6 max-w-md w-full">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold">Schedule Social Media Posts</h3>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4">
          {platforms.map(platform => (
            <div key={platform.id} className="flex items-center justify-between p-3 border rounded-lg">
              <div className="flex items-center gap-3">
                <div className="text-gray-600">{platform.icon}</div>
                <div>
                  <span className="font-medium">{platform.name}</span>
                  {platform.characterLimit && (
                    <p className="text-xs text-gray-500">Max {platform.characterLimit} characters</p>
                  )}
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                {platform.enabled && (
                  <input
                    type="datetime-local"
                    className="px-2 py-1 border rounded"
                    onChange={(e) => handleTimeChange(platform.id, e.target.value)}
                  />
                )}
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    className="sr-only peer"
                    checked={platform.enabled}
                    onChange={() => handleTogglePlatform(platform.id)}
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                </label>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-6 flex justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 text-gray-600 hover:text-gray-800"
          >
            Cancel
          </button>
          <button
            onClick={() => onSchedule(platforms.filter(p => p.enabled))}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            Schedule Posts
          </button>
        </div>
      </div>
    </div>
  );
}