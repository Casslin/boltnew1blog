import React from 'react';
import { Filter } from 'lucide-react';

interface StatusFilterProps {
  value: 'all' | 'upcoming' | 'completed';
  onChange: (value: 'all' | 'upcoming' | 'completed') => void;
}

export function StatusFilter({ value, onChange }: StatusFilterProps) {
  return (
    <div className="relative">
      <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
      <select
        className="pl-10 pr-8 py-2 border border-gray-300 rounded-lg appearance-none bg-white focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        value={value}
        onChange={(e) => onChange(e.target.value as 'all' | 'upcoming' | 'completed')}
      >
        <option value="all">All Meetings</option>
        <option value="upcoming">Upcoming</option>
        <option value="completed">Completed</option>
      </select>
    </div>
  );
}