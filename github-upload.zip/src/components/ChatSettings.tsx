import React, { useState } from 'react';
import { X, Save, Globe, Database, Hash } from 'lucide-react';
import { SocialPlatformStatus } from '../types/blog';

interface ChatSettingsProps {
  settings: {
    ensDomain: string;
    solDomain: string;
    autoPublishToIPFS: boolean;
    defaultPlatforms: SocialPlatformStatus['platform'][];
  };
  onSave: (settings: ChatSettingsProps['settings']) => void;
  onClose: () => void;
}

export function ChatSettings({ settings, onSave, onClose }: ChatSettingsProps) {
  const [formData, setFormData] = useState(settings);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  const platforms: SocialPlatformStatus['platform'][] = [
    'twitter', 'linkedin', 'medium', 'farcaster', 'bluesky'
  ];

  return (
    <div className="fixed inset-0 bg-black/20 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-white/95 rounded-2xl p-6 max-w-md w-full shadow-xl border border-gray-100/50">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-semibold text-gray-800">Settings</h3>
          <button onClick={onClose} className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100/50 rounded-lg transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <div className="flex items-center gap-1">
                <Hash className="w-4 h-4" />
                ENS Domain
              </div>
            </label>
            <input
              type="text"
              value={formData.ensDomain}
              onChange={(e) => setFormData({ ...formData, ensDomain: e.target.value })}
              placeholder="yourdomain.eth"
              className="w-full px-4 py-2.5 bg-gray-50/50 border border-gray-200/75 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-400 transition-all placeholder:text-gray-400"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              <div className="flex items-center gap-1">
                <Globe className="w-4 h-4" />
                Solana Domain
              </div>
            </label>
            <input
              type="text"
              value={formData.solDomain}
              onChange={(e) => setFormData({ ...formData, solDomain: e.target.value })}
              placeholder="yourdomain.sol"
              className="w-full px-4 py-2.5 bg-gray-50/50 border border-gray-200/75 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-400 transition-all placeholder:text-gray-400"
            />
          </div>

          <div>
            <label className="flex items-center gap-2 text-sm font-medium text-gray-700">
              <input
                type="checkbox"
                checked={formData.autoPublishToIPFS}
                onChange={(e) => setFormData({ ...formData, autoPublishToIPFS: e.target.checked })}
                className="rounded text-indigo-600 focus:ring-indigo-500/20 transition-colors"
              />
              <div className="flex items-center gap-1">
                <Database className="w-4 h-4" />
                Auto-publish to IPFS
              </div>
            </label>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Default Publishing Platforms
            </label>
            <div className="space-y-2">
              {platforms.map(platform => (
                <label key={platform} className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={formData.defaultPlatforms.includes(platform)}
                    onChange={(e) => {
                      const newPlatforms = e.target.checked
                        ? [...formData.defaultPlatforms, platform]
                        : formData.defaultPlatforms.filter(p => p !== platform);
                      setFormData({ ...formData, defaultPlatforms: newPlatforms });
                    }}
                    className="rounded text-indigo-600 focus:ring-indigo-500/20 transition-colors"
                  />
                  <span className="text-sm text-gray-600 capitalize">{platform}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 text-gray-600 hover:text-gray-800 hover:bg-gray-50 rounded-xl transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-4 py-2.5 bg-gradient-to-br from-indigo-500 to-indigo-600 text-white rounded-xl hover:from-indigo-600 hover:to-indigo-700 transition-all shadow-sm hover:shadow flex items-center gap-2"
            >
              <Save className="w-4 h-4" />
              Save Settings
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}