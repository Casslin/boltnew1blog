import React, { useState } from 'react';
import { Meeting } from '../types/meeting';
import { MeetingCard } from './MeetingCard';
import { SearchBar } from './SearchBar';
import { StatusFilter } from './StatusFilter';
import { filterMeetings } from '../utils/filters';

interface DashboardProps {
  meetings: Meeting[];
}

export function Dashboard({ meetings }: DashboardProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'upcoming' | 'completed'>('all');

  const filteredMeetings = filterMeetings(meetings, searchTerm, statusFilter);

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Meeting Assistant</h1>
        <p className="text-gray-600">Track your meetings, action items, and related documents</p>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <SearchBar
          value={searchTerm}
          onChange={setSearchTerm}
          placeholder="Search meetings and action items..."
        />
        <StatusFilter
          value={statusFilter}
          onChange={setStatusFilter}
        />
      </div>

      <div className="space-y-4">
        {filteredMeetings.length > 0 ? (
          filteredMeetings.map(meeting => (
            <MeetingCard key={meeting.id} meeting={meeting} />
          ))
        ) : (
          <div className="text-center py-8 text-gray-500">
            No meetings found matching your criteria
          </div>
        )}
      </div>
    </div>
  );
}