import React from 'react';
import { Calendar, Clock, Users } from 'lucide-react';
import { Meeting } from '../types/meeting';
import { ActionItems } from './ActionItems';
import { RelatedDocs } from './RelatedDocs';
import { formatDate, formatTime } from '../utils/dates';

interface MeetingCardProps {
  meeting: Meeting;
}

export function MeetingCard({ meeting }: MeetingCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-4">
      <div className="flex justify-between items-start mb-4">
        <h3 className="text-lg font-semibold text-gray-900">{meeting.title}</h3>
        <span className={`px-2 py-1 rounded text-sm ${
          meeting.status === 'upcoming' 
            ? 'bg-blue-100 text-blue-800' 
            : 'bg-green-100 text-green-800'
        }`}>
          {meeting.status}
        </span>
      </div>
      
      <div className="space-y-3">
        <div className="flex items-center text-gray-600">
          <Calendar className="w-4 h-4 mr-2" />
          <span>{formatDate(meeting.date)}</span>
        </div>
        
        <div className="flex items-center text-gray-600">
          <Clock className="w-4 h-4 mr-2" />
          <span>{formatTime(meeting.startTime)} - {formatTime(meeting.endTime)}</span>
        </div>
        
        <div className="flex items-center text-gray-600">
          <Users className="w-4 h-4 mr-2" />
          <span>{meeting.attendees.join(', ')}</span>
        </div>
      </div>

      <ActionItems items={meeting.actionItems} />
      <RelatedDocs documents={meeting.relatedDocs} />
    </div>
  );
}