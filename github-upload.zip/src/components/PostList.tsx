import React from 'react';
import { Post } from '../types/blog';
import { Calendar, Tag, Share2 } from 'lucide-react';

interface PostListProps {
  posts: Post[];
  onEditPost: (post: Post) => void;
}

export function PostList({ posts, onEditPost }: PostListProps) {
  return (
    <div className="space-y-6">
      {posts.map(post => (
        <article
          key={post.id}
          className="bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow"
        >
          {post.coverImage && (
            <img
              src={post.coverImage}
              alt={post.title}
              className="w-full h-48 object-cover rounded-t-lg"
            />
          )}
          <div className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-gray-900">{post.title}</h2>
              <span className={`px-3 py-1 rounded-full text-sm ${
                post.status === 'published' 
                  ? 'bg-green-100 text-green-800'
                  : 'bg-yellow-100 text-yellow-800'
              }`}>
                {post.status}
              </span>
            </div>
            
            <p className="text-gray-600 mb-4">{post.excerpt}</p>
            
            <div className="flex items-center gap-4 text-sm text-gray-500">
              <div className="flex items-center">
                <Calendar className="w-4 h-4 mr-1" />
                {new Date(post.publishedAt).toLocaleDateString()}
              </div>
              <div className="flex items-center">
                <Tag className="w-4 h-4 mr-1" />
                {post.tags.join(', ')}
              </div>
              <div className="flex items-center">
                <Share2 className="w-4 h-4 mr-1" />
                {post.socialPlatforms.length} platforms
              </div>
            </div>
            
            <div className="mt-4 pt-4 border-t flex justify-between items-center">
              <div className="flex items-center">
                <img
                  src={post.author.avatar}
                  alt={post.author.name}
                  className="w-8 h-8 rounded-full mr-2"
                />
                <span className="text-sm font-medium text-gray-700">
                  {post.author.name}
                </span>
              </div>
              
              <button
                onClick={() => onEditPost(post)}
                className="px-4 py-2 text-sm font-medium text-indigo-600 hover:text-indigo-500"
              >
                Edit Post
              </button>
            </div>
          </div>
        </article>
      ))}
    </div>
  );
}