import React, { useState } from 'react';
import { Bot, Send, Sparkles, Calendar, Share2, Database, Globe, Settings, Hash, Minimize2, Maximize2 } from 'lucide-react';
import { schedulePost } from '../services/socialMedia';
import { publishToDecentralized } from '../services/ipfs';
import { SocialPlatformStatus } from '../types/blog';
import { ChatSettings } from './ChatSettings';

interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: Date;
  suggestions?: {
    platforms?: SocialPlatformStatus['platform'][];
  };
}

interface AIChatAssistantProps {
  onSuggest: (suggestion: { title?: string; content?: string; tags?: string[] }) => void;
}


interface ChatSettings {
  ensDomain: string;
  solDomain: string;
  autoPublishToIPFS: boolean;
  defaultPlatforms: SocialPlatformStatus['platform'][];
}

export function AIChatAssistant({ onSuggest }: AIChatAssistantProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      content: 'Hello! I can help you write and share content across various platforms.',
      role: 'assistant',
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [showPlatformSuggestions, setShowPlatformSuggestions] = useState(false);
  const [selectedContent, setSelectedContent] = useState<string>('');
  const [showSettings, setShowSettings] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [settings, setSettings] = useState<ChatSettings>({
    ensDomain: '',
    solDomain: '',
    autoPublishToIPFS: false,
    defaultPlatforms: ['twitter', 'farcaster']
  });

  const handleSettingsUpdate = (newSettings: ChatSettings) => {
    setSettings(newSettings);
    setShowSettings(false);
  };

  const handlePublishToDecentralized = async (content: string, platform: 'ipfs' | 'ens' | 'sol') => {
    try {
      const domain = platform === 'ens' ? settings.ensDomain : platform === 'sol' ? settings.solDomain : undefined;
      const result = await publishToDecentralized(content, platform, domain);
      
      const aiResponse: Message = {
        id: Date.now().toString(),
        content: `Successfully published to ${platform.toUpperCase()}${result.publishedUrl ? `: ${result.publishedUrl}` : ''}`,
        role: 'assistant',
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, aiResponse]);
    } catch (error) {
      console.error(`Failed to publish to ${platform}:`, error);
      const errorMessage: Message = {
        id: Date.now().toString(),
        content: `Failed to publish to ${platform}. Please try again.`,
        role: 'assistant',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    }
  };

  const handleSchedulePosts = async (platforms: SocialPlatformStatus['platform'][], content: string) => {
    try {
      const results = await Promise.all(
        platforms.map(platform => schedulePost(content, platform))
      );

      const successfulPlatforms = results
        .filter(result => result.success)
        .map(result => result.platform);

      const aiResponse: Message = {
        id: Date.now().toString(),
        content: `Successfully scheduled posts on: ${successfulPlatforms.join(', ')}`,
        role: 'assistant',
        timestamp: new Date()
      };

      setMessages(prev => [...prev, aiResponse]);
    } catch (error) {
      console.error('Failed to schedule posts:', error);
      const errorMessage: Message = {
        id: Date.now().toString(),
        content: 'Failed to schedule posts. Please try again.',
        role: 'assistant',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    }
  };

  const handleSend = () => {
    if (input.trim() === '') return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: input,
      role: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');

    // Simulate AI response (replace with actual AI service call)
    const aiResponse: Message = {
      id: Date.now().toString(),
      content: 'Generating suggestions...',
      role: 'assistant',
      timestamp: new Date(),
      suggestions: {
        platforms: ['twitter', 'linkedin', 'farcaster']
      }
    };

    setMessages(prev => [...prev, aiResponse]);
    setSelectedContent(input);
    setShowPlatformSuggestions(true);
  };

  return (
    <div className={`fixed bottom-4 right-4 w-[400px] bg-white/95 backdrop-blur-sm rounded-2xl shadow-xl border border-gray-100/50 transition-all duration-300 ${
      isMinimized ? 'h-[60px]' : ''
    }`}>
      <div className="flex items-center justify-between p-4 border-b">
        <div className="flex items-center gap-2">
          <div className="bg-gradient-to-br from-indigo-50 to-indigo-100 p-2 rounded-xl shadow-sm">
            <Bot className="w-5 h-5 text-indigo-600" />
          </div>
          <h3 className="font-semibold text-gray-800">
            {isMinimized ? 'AI Assistant (Click to expand)' : 'AI Writing Assistant'}
          </h3>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsMinimized(!isMinimized)}
            className="p-2 hover:bg-gray-50 rounded-xl transition-all hover:shadow-sm"
            title={isMinimized ? 'Expand' : 'Minimize'}
          >
            {isMinimized ? (
              <Maximize2 className="w-5 h-5 text-gray-600" />
            ) : (
              <Minimize2 className="w-5 h-5 text-gray-600" />
            )}
          </button>
          <button
            onClick={() => setShowSettings(true)}
            className="p-2 hover:bg-gray-50 rounded-xl transition-all hover:shadow-sm"
            title="Settings"
          >
            <Settings className="w-5 h-5 text-gray-600" />
          </button>
          <div className="bg-gradient-to-br from-indigo-50 to-indigo-100 p-2 rounded-xl shadow-sm">
            <Sparkles className="w-5 h-5 text-indigo-600" />
          </div>
        </div>
      </div>

      <div className={`${isMinimized ? 'hidden' : 'h-[450px] overflow-y-auto p-4 space-y-6'}`}>
        {messages.map(message => (
          <div
            key={message.id}
            className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[80%] rounded-lg p-3 ${
                message.role === 'user'
                  ? 'bg-gradient-to-br from-indigo-500 to-indigo-600 text-white shadow-sm'
                  : 'bg-gray-50/80 text-gray-900 shadow-sm ring-1 ring-gray-100'
              }`}
            >
              <p className="text-sm">{message.content}</p>
              <span className="text-xs opacity-70 mt-1 block">
                {message.timestamp.toLocaleTimeString()}
              </span>
              {message.suggestions && (
                <div className="mt-3 space-y-2">
                  <div className="flex flex-wrap gap-2">
                    {message.content.toLowerCase().includes('publish') && (
                      <>
                        <button
                          onClick={() => handlePublishToDecentralized(selectedContent, 'ipfs')}
                          className="inline-flex items-center px-3 py-1.5 rounded-full text-xs font-medium bg-purple-50 text-purple-700 hover:bg-purple-100 transition-colors shadow-sm ring-1 ring-purple-100"
                        >
                          <Database className="w-3 h-3 mr-1" />
                          IPFS
                        </button>
                        {settings.ensDomain && (
                          <button
                            onClick={() => handlePublishToDecentralized(selectedContent, 'ens')}
                            className="inline-flex items-center px-3 py-1.5 rounded-full text-xs font-medium bg-blue-50 text-blue-700 hover:bg-blue-100 transition-colors shadow-sm ring-1 ring-blue-100"
                          >
                            <Hash className="w-3 h-3 mr-1" />
                            ENS
                          </button>
                        )}
                        {settings.solDomain && (
                          <button
                            onClick={() => handlePublishToDecentralized(selectedContent, 'sol')}
                            className="inline-flex items-center px-3 py-1.5 rounded-full text-xs font-medium bg-purple-50 text-purple-700 hover:bg-purple-100 transition-colors shadow-sm ring-1 ring-purple-100"
                          >
                            <Globe className="w-3 h-3 mr-1" />
                            Solana
                          </button>
                        )}
                      </>
                    )}
                    {message.suggestions.platforms?.map(platform => (
                      <button
                        key={platform}
                        onClick={() => handleSchedulePosts([platform], selectedContent)}
                        className={`inline-flex items-center px-3 py-1.5 rounded-full text-xs font-medium transition-all shadow-sm ${
                          platform === 'ipfs' || platform === 'ens' || platform === 'sol'
                            ? 'bg-purple-50 text-purple-700 hover:bg-purple-100 ring-1 ring-purple-100'
                            : 'bg-indigo-50 text-indigo-700 hover:bg-indigo-100 ring-1 ring-indigo-100'
                        }`}
                      >
                        {platform === 'ipfs' ? (
                          <Database className="w-3 h-3 mr-1" />
                        ) : platform === 'ens' || platform === 'sol' ? (
                          <Globe className="w-3 h-3 mr-1" />
                        ) : (
                          <Share2 className="w-3 h-3 mr-1" />
                        )}
                        {platform}
                      </button>
                    ))}
                  </div>
                  <button
                    onClick={() => handleSchedulePosts(message.suggestions.platforms || [], selectedContent)}
                    className="inline-flex items-center px-3 py-1.5 rounded-full bg-green-50 text-green-700 text-xs font-medium hover:bg-green-100 transition-colors shadow-sm ring-1 ring-green-100"
                  >
                    <Calendar className="w-3 h-3 mr-1" />
                    Schedule All
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      <div className={`p-4 border-t ${isMinimized ? 'hidden' : ''}`}>
        <div className="flex gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Type a message..."
            className="flex-1 px-4 py-3 bg-gray-50/50 border border-gray-200/75 rounded-xl focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-400 transition-all placeholder:text-gray-400"
          />
          <button
            onClick={handleSend}
            className="p-3 bg-gradient-to-br from-indigo-500 to-indigo-600 text-white rounded-xl hover:from-indigo-600 hover:to-indigo-700 transition-all shadow-sm hover:shadow"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
      
      {showSettings && (
        <ChatSettings
          settings={settings}
          onSave={handleSettingsUpdate}
          onClose={() => setShowSettings(false)}
        />
      )}
    </div>
  );
}