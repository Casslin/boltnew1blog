import React, { useState } from 'react';
import { Post } from '../types/blog';
import { Calendar, Tag, Globe, Sparkles } from 'lucide-react';
import { SocialScheduler } from './SocialScheduler';

interface PostEditorProps {
  post?: Post;
  onSave: (post: Partial<Post>) => void;
  onCancel: () => void;
}

export function PostEditor({ post, onSave, onCancel }: PostEditorProps) {
  const [title, setTitle] = useState(post?.title || '');
  const [content, setContent] = useState(post?.content || '');
  const [excerpt, setExcerpt] = useState(post?.excerpt || '');
  const [tags, setTags] = useState<string[]>(post?.tags || []);
  const [showScheduler, setShowScheduler] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      title,
      content,
      excerpt,
      tags,
      status: 'draft',
      publishedAt: new Date().toISOString(),
    });
  };

  const handleTagInput = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter' && e.currentTarget.value) {
      e.preventDefault();
      const newTag = e.currentTarget.value.trim();
      if (newTag && !tags.includes(newTag)) {
        setTags([...tags, newTag]);
        e.currentTarget.value = '';
      }
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Title
          </label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="Enter post title..."
          />
          <button
            type="button"
            onClick={() => console.log('Requesting AI title suggestions')}
            className="absolute right-2 top-8 p-1 text-gray-400 hover:text-indigo-600"
            title="Get AI suggestions"
          >
            <Sparkles className="w-5 h-5" />
          </button>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Content
          </label>
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            rows={10}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="Write your post content..."
          />
          <button
            type="button"
            onClick={() => console.log('Requesting AI content improvements')}
            className="mt-2 text-sm text-indigo-600 hover:text-indigo-700 flex items-center gap-1"
          >
            <Sparkles className="w-4 h-4" />
            Improve with AI
          </button>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Excerpt
          </label>
          <textarea
            value={excerpt}
            onChange={(e) => setExcerpt(e.target.value)}
            rows={2}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="Write a brief excerpt..."
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Tags
          </label>
          <div className="flex flex-wrap gap-2 mb-2">
            {tags.map((tag) => (
              <span
                key={tag}
                className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-sm"
              >
                {tag}
                <button
                  type="button"
                  onClick={() => setTags(tags.filter((t) => t !== tag))}
                  className="ml-2 text-blue-600 hover:text-blue-800"
                >
                  ×
                </button>
              </span>
            ))}
          </div>
          <input
            type="text"
            onKeyDown={handleTagInput}
            className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
            placeholder="Type a tag and press Enter..."
          />
        </div>

        <div className="flex justify-between items-center pt-4 border-t">
          <div className="space-x-2">
            <button
              type="submit"
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              Save Draft
            </button>
            <button
              type="button"
              onClick={() => setShowScheduler(true)}
              className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
            >
              Schedule Post
            </button>
          </div>
          <button
            type="button"
            onClick={onCancel}
            className="px-4 py-2 text-gray-600 hover:text-gray-800"
          >
            Cancel
          </button>
        </div>
      </form>

      {showScheduler && (
        <SocialScheduler
          onClose={() => setShowScheduler(false)}
          onSchedule={(platforms) => {
            console.log('Scheduling for platforms:', platforms);
            setShowScheduler(false);
          }}
        />
      )}
    </div>
  );
}