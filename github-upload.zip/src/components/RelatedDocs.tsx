import React from 'react';
import { FileText } from 'lucide-react';
import { RelatedDocument } from '../types/meeting';

interface RelatedDocsProps {
  documents: RelatedDocument[];
}

export function RelatedDocs({ documents }: RelatedDocsProps) {
  if (documents.length === 0) return null;

  return (
    <div className="mt-4">
      <h4 className="text-sm font-semibold text-gray-700 mb-2 flex items-center">
        <FileText className="w-4 h-4 mr-1" />
        Related Documents
      </h4>
      <ul className="space-y-2">
        {documents.map(doc => (
          <li key={doc.id} className="text-sm">
            <a href={doc.url} className="text-blue-600 hover:text-blue-800">
              {doc.title}
            </a>
            <span className="text-xs text-gray-500 ml-2">
              • {doc.type} • Modified: {doc.lastModified}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}