import React from 'react';
import { Framework } from '../types/agent';
import { Settings, Check } from 'lucide-react';

interface FrameworkSelectorProps {
  frameworks: Framework[];
  onSelect: (framework: Framework) => void;
}

export function FrameworkSelector({ frameworks, onSelect }: FrameworkSelectorProps) {
  return (
    <div className="border-b bg-gray-50 p-4">
      <div className="flex items-center gap-2 mb-3">
        <Settings className="w-5 h-5 text-gray-600" />
        <h3 className="text-sm font-semibold text-gray-700">Trading Frameworks</h3>
      </div>
      <div className="space-y-2">
        {frameworks.map(framework => (
          <button
            key={framework.id}
            onClick={() => onSelect(framework)}
            className={`w-full text-left p-3 rounded-lg transition-colors ${
              framework.active
                ? 'bg-blue-50 border border-blue-200'
                : 'bg-white border hover:bg-gray-50'
            }`}
          >
            <div className="flex items-center justify-between">
              <div>
                <h4 className="font-medium text-gray-900">{framework.name}</h4>
                <p className="text-sm text-gray-600">{framework.description}</p>
              </div>
              {framework.active && (
                <Check className="w-5 h-5 text-blue-500" />
              )}
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}