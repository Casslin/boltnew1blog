import React from 'react';
import { CheckSquare } from 'lucide-react';
import { ActionItem } from '../types/meeting';
import { isOverdue, formatDate } from '../utils/dates';

interface ActionItemsProps {
  items: ActionItem[];
}

export function ActionItems({ items }: ActionItemsProps) {
  if (items.length === 0) return null;

  return (
    <div className="mt-4">
      <h4 className="text-sm font-semibold text-gray-700 mb-2 flex items-center">
        <CheckSquare className="w-4 h-4 mr-1" />
        Action Items
      </h4>
      <ul className="space-y-2">
        {items.map(item => (
          <li key={item.id} className="flex items-start">
            <span className={`w-2 h-2 rounded-full mt-1.5 mr-2 ${
              item.status === 'completed' 
                ? 'bg-green-500' 
                : isOverdue(item.dueDate)
                ? 'bg-red-500'
                : 'bg-yellow-500'
            }`} />
            <div>
              <p className="text-sm text-gray-700">{item.text}</p>
              <p className="text-xs text-gray-500">
                {item.assignee} • Due: {formatDate(item.dueDate)}
              </p>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}